package com.yinni.lab;

import android.app.Activity;
import android.app.AppOpsManager;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.app.usage.UsageEvents;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class UsageMonitorActivity extends Activity {
    private LinearLayout list;
    private TextView summary;
    private final SimpleDateFormat timeFmt = new SimpleDateFormat("MM-dd HH:mm:ss", Locale.getDefault());
    private boolean hasAccess() {
        AppOpsManager ops=(AppOpsManager)getSystemService(Context.APP_OPS_SERVICE);
        int mode=ops.checkOpNoThrow("android:get_usage_stats", android.os.Process.myUid(), getPackageName());
        return mode==AppOpsManager.MODE_ALLOWED;
    }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(22,22,22,22); root.setBackgroundColor(0xFFF5F6FA);
        ScrollView sc=new ScrollView(this); sc.addView(root);
        TextView title=new TextView(this); title.setText("手机使用状态监测"); title.setTextSize(25); title.setTextColor(0xFF18233A); title.setGravity(Gravity.CENTER); root.addView(title,new LinearLayout.LayoutParams(-1,-2));
        TextView note=new TextView(this); note.setText("本机本地统计 · 不上传数据\n首次使用需在系统设置中允许“使用情况访问”。不同 Android 版本可能限制锁屏/解锁事件记录。"); note.setTextSize(14); note.setTextColor(0xFF596579); note.setPadding(0,12,0,14); root.addView(note);
        Button grant=new Button(this); grant.setText("① 开启使用情况访问权限"); grant.setAllCaps(false); grant.setOnClickListener(v->{try{startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));}catch(Exception e){startActivity(new Intent(Settings.ACTION_SETTINGS));}}); root.addView(grant);
        Button refresh=new Button(this); refresh.setText("② 刷新最近 24 小时统计"); refresh.setAllCaps(false); refresh.setOnClickListener(v->render()); root.addView(refresh);
        summary=new TextView(this); summary.setTextSize(16); summary.setTextColor(0xFF18233A); summary.setPadding(0,16,0,12); root.addView(summary);
        TextView hdr=new TextView(this); hdr.setText("各 APP 使用时长（最近 24 小时）"); hdr.setTextSize(18); hdr.setTextColor(0xFF18233A); root.addView(hdr);
        list=new LinearLayout(this); list.setOrientation(1); root.addView(list);
        TextView extras=new TextView(this); extras.setText("其他功能说明\n• 最近打开/切换到前台的 APP 与时间\n• 估算屏幕亮起/解锁事件（系统允许时）\n• APP 使用时长排行\n• 今日总使用时长与使用次数线索\n• 数据只从 Android 系统使用统计读取；不监控屏幕内容、聊天内容或输入密码。\n\n注意：系统统计不一定等于实际盯屏时间；部分厂商系统会合并、延迟或限制事件。应用被强行停止、重启或系统限制也会造成缺漏。"); extras.setTextSize(14); extras.setTextColor(0xFF596579); extras.setPadding(0,18,0,10); root.addView(extras);
        setContentView(sc);
    }
    @Override protected void onResume(){super.onResume();render();}
    private String dur(long ms){long m=ms/60000; if(m<60)return m+" 分钟"; return (m/60)+" 小时 "+(m%60)+" 分钟";}
    private void render(){
        list.removeAllViews(); if(!hasAccess()){summary.setText("尚未获得使用情况访问权限。请点上方按钮，在系统设置中找到“隐匿实验室”并允许访问，然后返回此页面刷新。"); return;}
        long end=System.currentTimeMillis(), start=end-24L*60*60*1000;
        UsageStatsManager usm=(UsageStatsManager)getSystemService(USAGE_STATS_SERVICE);
        Map<String,UsageStats> map=usm.queryAndAggregateUsageStats(start,end);
        ArrayList<UsageStats> arr=new ArrayList<>(); if(map!=null)for(UsageStats u:map.values())if(u.getTotalTimeInForeground()>0)arr.add(u);
        Collections.sort(arr,(a,b)->Long.compare(b.getTotalTimeInForeground(),a.getTotalTimeInForeground()));
        long total=0;for(UsageStats u:arr)total+=u.getTotalTimeInForeground();
        summary.setText("统计区间："+timeFmt.format(new Date(start))+" 至现在\n有使用记录的 APP："+arr.size()+" 个\n前台累计时长（各 APP 相加）："+dur(total)+"\n\n最近系统记录的亮屏/解锁/APP 前台事件：");
        UsageEvents ev=usm.queryEvents(start,end); UsageEvents.Event e=new UsageEvents.Event(); ArrayList<String> events=new ArrayList<>();
        while(ev!=null&&ev.hasNextEvent()){ev.getNextEvent(e);int t=e.getEventType();String label=null;
            if(t==UsageEvents.Event.SCREEN_INTERACTIVE)label="屏幕亮起";
            else if(t==UsageEvents.Event.SCREEN_NON_INTERACTIVE)label="屏幕熄灭";
            else if(t==UsageEvents.Event.KEYGUARD_HIDDEN)label="锁屏解除（系统有记录时）";
            else if(t==UsageEvents.Event.MOVE_TO_FOREGROUND)label="打开/切到前台："+appName(e.getPackageName());
            if(label!=null)events.add(timeFmt.format(new Date(e.getTimeStamp()))+"  ·  "+label);
        }
        int shown=0;for(int i=events.size()-1;i>=0&&shown<100;i--){TextView tv=new TextView(this);tv.setText(events.get(i));tv.setTextSize(13);tv.setTextColor(0xFF37445C);tv.setPadding(0,5,0,5);list.addView(tv);shown++;}
        if(events.isEmpty()){TextView tv=new TextView(this);tv.setText("系统暂未提供这些事件记录。");list.addView(tv);}
        TextView spacer=new TextView(this);spacer.setText("\nAPP 使用时长排行");spacer.setTextSize(18);spacer.setTextColor(0xFF18233A);list.addView(spacer);
        int count=0;for(UsageStats u:arr){if(count++>=60)break;TextView tv=new TextView(this);tv.setText(appName(u.getPackageName())+"\n"+dur(u.getTotalTimeInForeground())+"   ·   包名："+u.getPackageName());tv.setTextSize(14);tv.setTextColor(0xFF37445C);tv.setPadding(0,9,0,9);list.addView(tv);View line=new View(this);line.setBackgroundColor(0xFFD8DDE6);list.addView(line,new LinearLayout.LayoutParams(-1,1));}
    }
    private String appName(String pkg){try{return getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(pkg,0)).toString();}catch(Exception ex){return pkg;}}
}
