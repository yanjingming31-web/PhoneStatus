package com.yinni.lab;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.*;
import java.security.SecureRandom;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class MainActivity extends Activity {
    private static final int PICK_COVER=1, PICK_SECRET=2, PICK_STEGO=3;
    private Uri coverUri, secretUri, stegoUri;
    private TextView status, coverLabel, secretLabel, stegoLabel;
    private EditText password;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this); root.setOrientation(1); root.setPadding(22,24,22,22); root.setBackgroundColor(0xFFF5F6FA);
        ScrollView scroll = new ScrollView(this); scroll.addView(root);
        TextView title = new TextView(this); title.setText("隐匿实验室"); title.setTextSize(28); title.setTextColor(0xFF18233A); title.setGravity(Gravity.CENTER); root.addView(title, matchWrap());
        TextView sub = new TextView(this); sub.setText("图片藏图 · 本地加密工具"); sub.setTextSize(15); sub.setTextColor(0xFF65718A); sub.setGravity(Gravity.CENTER); sub.setPadding(0,4,0,22); root.addView(sub, matchWrap());
        addButton(root,"📱 手机使用状态监测",v->startActivity(new Intent(this, UsageMonitorActivity.class)));
        addButton(root,"① 选择封面图片（PNG/JPG）",v->pick(PICK_COVER)); coverLabel=label(root,"尚未选择封面图片");
        addButton(root,"② 选择要藏起来的图片",v->pick(PICK_SECRET)); secretLabel=label(root,"尚未选择秘密图片");
        password = new EditText(this); password.setSingleLine(true); password.setHint("设置提取密码（至少 6 位）"); password.setInputType(129); root.addView(password, matchWrap());
        addButton(root,"🔒 加密并藏入封面",v->hideImage());
        addButton(root,"③ 选择已藏图的 PNG 图片",v->pick(PICK_STEGO)); stegoLabel=label(root,"尚未选择待提取图片");
        addButton(root,"🔓 提取并恢复秘密图片",v->extractImage());
        status=new TextView(this); status.setText("提示：输出请保存为 PNG。不要用社交软件压缩或转发藏图。"); status.setTextColor(0xFF37445C); status.setTextSize(14); status.setPadding(4,18,4,4); root.addView(status,matchWrap());
        setContentView(scroll);
    }
    private LinearLayout.LayoutParams matchWrap(){return new LinearLayout.LayoutParams(-1,-2);}
    private TextView label(LinearLayout root,String text){TextView t=new TextView(this);t.setText(text);t.setTextColor(0xFF65718A);t.setTextSize(13);t.setPadding(4,3,4,12);root.addView(t,matchWrap());return t;}
    private void addButton(LinearLayout root,String text,View.OnClickListener l){Button b=new Button(this);b.setText(text);b.setAllCaps(false);b.setOnClickListener(l);LinearLayout.LayoutParams p=matchWrap();p.bottomMargin=5;root.addView(b,p);}
    private void pick(int req){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,req);}
    @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(result!=RESULT_OK||data==null)return;Uri u=data.getData();try{if(req==10){if(pendingBitmap==null)throw new Exception("没有可保存的藏图");try(OutputStream out=getContentResolver().openOutputStream(u)){if(out==null)throw new Exception("无法打开保存位置");pendingBitmap.compress(Bitmap.CompressFormat.PNG,100,out);}pendingBitmap=null;msg("藏图已保存为 PNG。请勿压缩或转成 JPG。");return;}if(req==11){if(pendingBytes==null)throw new Exception("没有可保存的数据");try(OutputStream out=getContentResolver().openOutputStream(u)){if(out==null)throw new Exception("无法打开保存位置");out.write(pendingBytes);}pendingBytes=null;msg("秘密图片已恢复并保存。");return;}}catch(Exception e){msg("保存失败："+e.getMessage());return;}if(req==PICK_COVER){coverUri=u;coverLabel.setText("封面已选择："+name(u));}if(req==PICK_SECRET){secretUri=u;secretLabel.setText("秘密图片已选择："+name(u));}if(req==PICK_STEGO){stegoUri=u;stegoLabel.setText("待提取图片已选择："+name(u));}}
    private String name(Uri u){String s=u.getLastPathSegment();return s==null?"已选择图片":s;}
    private Bitmap load(Uri u)throws Exception{try(InputStream in=getContentResolver().openInputStream(u)){Bitmap b=BitmapFactory.decodeStream(in);if(b==null)throw new Exception("无法读取图片");return b.copy(Bitmap.Config.ARGB_8888,true);}}
    private byte[] bytes(Uri u)throws Exception{try(InputStream in=getContentResolver().openInputStream(u);ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);return out.toByteArray();}}
    private byte[] key(String pass,byte[] salt)throws Exception{PBEKeySpec spec=new PBEKeySpec(pass.toCharArray(),salt,120000,256);byte[] k=SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();spec.clearPassword();return k;}
    private byte[] encrypt(byte[] plain,String pass)throws Exception{byte[] salt=new byte[16],iv=new byte[12];SecureRandom r=new SecureRandom();r.nextBytes(salt);r.nextBytes(iv);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,new SecretKeySpec(key(pass,salt),"AES"),new GCMParameterSpec(128,iv));byte[] enc=c.doFinal(plain);ByteArrayOutputStream o=new ByteArrayOutputStream();o.write(new byte[]{'Y','N','L','1'});o.write(salt);o.write(iv);o.write(enc);return o.toByteArray();}
    private byte[] decrypt(byte[] packed,String pass)throws Exception{if(packed.length<48||packed[0]!='Y'||packed[1]!='N'||packed[2]!='L'||packed[3]!='1')throw new Exception("没有找到本应用的藏图数据");byte[] salt=new byte[16],iv=new byte[12];System.arraycopy(packed,4,salt,0,16);System.arraycopy(packed,20,iv,0,12);byte[] enc=new byte[packed.length-32];System.arraycopy(packed,32,enc,0,enc.length);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,new SecretKeySpec(key(pass,salt),"AES"),new GCMParameterSpec(128,iv));return c.doFinal(enc);}
    private void hideImage(){try{String p=password.getText().toString();if(coverUri==null||secretUri==null)throw new Exception("请先选择封面和秘密图片");if(p.length()<6)throw new Exception("密码至少需要 6 位");Bitmap b=load(coverUri);byte[] payload=encrypt(bytes(secretUri),p);long cap=(long)b.getWidth()*b.getHeight()*3/8-4;if(payload.length>cap)throw new Exception("秘密图片太大，封面容量不足。请缩小秘密图片或换更大的封面。");byte[] all=new byte[payload.length+4];int n=payload.length;all[0]=(byte)(n>>>24);all[1]=(byte)(n>>>16);all[2]=(byte)(n>>>8);all[3]=(byte)n;System.arraycopy(payload,0,all,4,n);embed(b,all);savePng(b,"选择保存藏图的位置");}catch(Exception e){msg("操作失败："+e.getMessage());}}
    private void embed(Bitmap b,byte[] data){int bit=0,total=data.length*8;for(int y=0;y<b.getHeight()&&bit<total;y++)for(int x=0;x<b.getWidth()&&bit<total;x++){int c=b.getPixel(x,y);int r=(c>>16)&255,g=(c>>8)&255,bl=c&255;if(bit<total){r=(r&254)|((data[bit/8]>>(7-bit%8))&1);bit++;}if(bit<total){g=(g&254)|((data[bit/8]>>(7-bit%8))&1);bit++;}if(bit<total){bl=(bl&254)|((data[bit/8]>>(7-bit%8))&1);bit++;}b.setPixel(x,y,0xFF000000|(r<<16)|(g<<8)|bl);}}
    private byte[] readBits(Bitmap b,int count){byte[] out=new byte[count];int bit=0;for(int y=0;y<b.getHeight()&&bit<count*8;y++)for(int x=0;x<b.getWidth()&&bit<count*8;x++){int c=b.getPixel(x,y);int[] ch={(c>>16)&255,(c>>8)&255,c&255};for(int v:ch){if(bit<count*8){out[bit/8]=(byte)((out[bit/8]<<1)|(v&1));bit++;}}}if(bit<count*8)throw new RuntimeException("图片容量不足");return out;}
    private void extractImage(){try{String p=password.getText().toString();if(stegoUri==null)throw new Exception("请先选择待提取图片");if(p.length()<6)throw new Exception("请输入原密码");Bitmap b=load(stegoUri);byte[] head=readBits(b,4);int n=((head[0]&255)<<24)|((head[1]&255)<<16)|((head[2]&255)<<8)|(head[3]&255);long cap=(long)b.getWidth()*b.getHeight()*3/8-4;if(n<48||n>cap)throw new Exception("没有找到有效藏图，或图片已被压缩破坏");byte[] packed=readBits(b,n+4);byte[] payload=new byte[n];System.arraycopy(packed,4,payload,0,n);byte[] plain=decrypt(payload,p);saveBytes(plain,"选择保存恢复图片的位置","restored-image.png");}catch(Exception e){msg("提取失败：密码错误、图片已损坏或不是本应用生成的藏图。详情："+e.getMessage());}}
    private void savePng(Bitmap b,String title){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("image/png");i.putExtra(Intent.EXTRA_TITLE,"yinni-hidden.png");startActivityForResult(i,10);pendingBitmap=b;}
    private Bitmap pendingBitmap;
    private void saveBytes(byte[] bytes,String title,String filename){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("image/*");i.putExtra(Intent.EXTRA_TITLE,filename);pendingBytes=bytes;startActivityForResult(i,11);}
    private byte[] pendingBytes;
    @Override protected void onResume(){super.onResume();}
    private void msg(String s){status.setText(s);Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override public void onBackPressed(){super.onBackPressed();}
}
