# 隐匿实验室 Android 项目

当前源码包含：
- 图片藏图/取图：秘密图片使用 PBKDF2-HMAC-SHA256 派生密钥、AES-GCM 加密后，以 RGB LSB 写入封面图并保存 PNG。
- 手机使用情况监测：通过 Android UsageStats 查询应用前台使用时长与系统提供的活动事件。

## 构建
- JDK 17、Android SDK 35、Gradle 8.9、Android Gradle Plugin 8.7.3
- 项目根目录执行 `gradle assembleDebug`
- GitHub Actions 工作流位于 `.github/workflows/build.yml`

## 重要限制
- 手机使用统计需要用户在系统设置中手动授予“使用情况访问”权限。
- Android 的使用统计不等于真实注视时长；锁屏/解锁事件可能因系统版本、厂商限制而缺失。
- **屏幕画面回溯/间隔截图尚未实现于当前源码。** 要采集其他应用画面，需要用户逐次通过 Android MediaProjection 系统授权，并遵循前台服务通知等要求；部分安全窗口或 DRM 内容不能采集。不要把当前版本误认为能还原历史画面。
- 不申请 INTERNET 权限；本项目目前按本地处理设计，但这不等于经过独立安全审计。
- 隐写不等于绝对隐形或绝对安全。任何有损压缩、缩放、滤镜或社交平台处理都可能破坏隐藏数据。
